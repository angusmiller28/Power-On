﻿using System;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace miller0061072133.Views
{
    public partial class Checkout : System.Web.UI.Page
    {
        Customer customer;
        private static Random random = new Random();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["customer"] == null)
            {
                Session["customer"] = new Customer();
            }

            customer = (Customer)Session["customer"];

            if (!IsPostBack) //check if the webpage is loaded for the first time.
            {
                ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState

                // add items to title listbox
                lst_title.Items.Add("Mr");
                lst_title.Items.Add("Mrs");
                // add items to street type 
                txt_street_type.Items.Add("ST");
                txt_street_type.Items.Add("TER");
                txt_street_type.Items.Add("DR");
                txt_street_type.Items.Add("AVE");
            }
        }
        protected void btnBack_Click(object sender, EventArgs e)
        {
            if (ViewState["PreviousPage"] != null)  //Check if the ViewState 
                                                    //contains Previous page URL
            {
                Response.Redirect(ViewState["PreviousPage"].ToString());//Redirect to 
                                                                        //Previous page by retrieving the PreviousPage Url from ViewState.
            }
        }

        //  public Customer(string ID, string Title, string Fname, string Mname, string Lname, string Country, string State, string City, string suburb, string postcode, string streetType, string streetName, string streetNumber, string propertyName)
        protected void Button2_Click(object sender, EventArgs e)
        {
            // get customer data for session
            string title = lst_title.Text;
            string city = txt_city.Text;
            string country = txt_country.Text;
            string email = txt_email_address.Text;
            string fname = txt_fname.Text;
            string lname = txt_lname.Text;
            string mname = txt_mname.Text;
            string postcode = txt_postcode.Text;
            string property = txt_property_name.Text;
            string state = txt_state.Text;
            string streetName = txt_street_name.Text;
            string streetType = txt_street_type.Text;
            string suburb = txt_suburb.Text;
            string unitNumber = txt_unit_number.Text;
            string propertyName = txt_property_name.Text;
            string id = RandomString(32);

            // validate data
            bool valid = ValidateData(id, title, fname, mname, lname, country, state, city, suburb, postcode, streetType, streetName, unitNumber, propertyName,email);

            // save customer data to session
            if (valid)
            {
                customer.Insert(new Customer(id, title, fname, mname, lname, country, state, city, suburb, postcode, streetType, streetName, unitNumber, propertyName, email));
                Response.Redirect("Payment.aspx");
            }
        }
		
		public static string RandomString(int length)
		{
			const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_";
			return new string(Enumerable.Repeat(chars, length)
			  .Select(s => s[random.Next(s.Length)]).ToArray());
		}

        private bool ValidateData(string ID, string Title, string Fname, string Mname, string Lname, string Country, string State, string City, string suburb, string postcode, string streetType, string streetName, string streetNumber, string propertyName, string email){
            bool allValid = true;
            lbl_error.Text = "";
            Regex id_exp = new Regex(@"^[A-Za-z0-9_]{32}$");
            Match match = id_exp.Match(ID);
            if (match.Success == false){
                lbl_error.Text += "- ID is invalid -";
                allValid = false;
            }

			Regex email_exp = new Regex(@"^(?("")("".+?(?<!\\)""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9][\-a-z0-9]{0,22}[a-z0-9]))$");
            match = email_exp.Match(email);
			if (match.Success == false)
			{
				lbl_error.Text += "- Email is invalid -";
				allValid = false;
			}

			Regex street_number_exp = new Regex(@"^*[A-Za-z0-9]$");
            match = street_number_exp.Match(streetNumber);
			if (match.Success == false)
			{
				lbl_error.Text += "- Street Number is invalid -";
                allValid = false;
			}

            Regex title_exp = new Regex(@"(Mr|Mrs)");
			match = title_exp.Match(Title);
			if (match.Success == false)
			{
				lbl_error.Text += "- Title is invalid -";
                allValid = false;
			}

			Regex name_exp = new Regex(@"^*[A-Za-z]$");
			match = name_exp.Match(Fname);
			if (match.Success == false)
			{
				lbl_error.Text += "- First name is invalid -";
                allValid = false;
			}
			match = name_exp.Match(Mname);
			if (match.Success == false)
			{
				lbl_error.Text += "- Middle name is invalid -";
                allValid = false;
			}
			match = name_exp.Match(Lname);
			if (match.Success == false)
			{
				lbl_error.Text += "- Last name is invalid -";
                allValid = false;
			}
            match = name_exp.Match(Country);
			if (match.Success == false)
			{
				lbl_error.Text += "- Country is invalid -";
                allValid = false;
			}
			match = name_exp.Match(State);
			if (match.Success == false)
			{
				lbl_error.Text += " State is invalid";
                allValid = false;
			}
			match = name_exp.Match(City);
			if (match.Success == false)
			{ 
				lbl_error.Text += "- City is invalid -";
                allValid = false;
			}
            match = name_exp.Match(suburb);
			if (match.Success == false)
			{
				lbl_error.Text += "- Suburb is invalid -";
                allValid = false;
			}
            match = name_exp.Match(streetName);
			if (match.Success == false)
			{
				lbl_error.Text += "- Street Name is invalid -";
                allValid = false;
			}
			match = name_exp.Match(propertyName);
			if (match.Success == false)
			{
				lbl_error.Text += "- Property name is invalid -";
                allValid = false;
			}

            Regex postcode_exp = new Regex(@"^[0-9]{4}$");
            match = postcode_exp.Match(postcode);
			if (match.Success == false)
			{
				lbl_error.Text += "- Postcode is invalid -";
                allValid = false;
			}

            Regex street_type_exp = new Regex(@"(ST|TER|DR|AVE)");
            match = street_type_exp.Match(streetType);
            if (match.Success == false)
			{
				lbl_error.Text += "- Street type is invalid - ";
                allValid = false;
			}

            if (allValid){
              return true;  
            }
            return false;
        }
    }
}