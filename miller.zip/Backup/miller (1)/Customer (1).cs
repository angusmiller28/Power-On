﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace miller0061072133
{
    public class Customer
    {
        public string ID { get; set; }
        public string Title { get; set; }
        public string Fname { get; set; }
        public string Mname { get; set; }
        public string Lname { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string Suburb { get; set; }
        public string Postcode { get; set; }
        public string StreetType { get; set; }
        public string StreetName { get; set; }
        public string StreetNumber { get; set; }
        public string PropertyName { get; set; }
        public string Email { get; set; }
        public string CardHoldersName { get; set; }
        public string CardNumber { get; set; }
        public string CardStartDate { get; set; }
        public string CardEndDate { get; set; }
        public string CardIssueNumber { get; set; }

        public Customer()
        {
            Console.Write("Hello");
        }

        public Customer(string ID, string Title, string Fname, string Mname, string Lname, string Country, string State, string City, string suburb, string postcode, string streetType, string streetName, string streetNumber, string propertyName, string email)
        {
            this.ID = ID;
            this.Title = Title;
            this.Fname = Fname;
            this.Mname = Mname;
            this.Lname = Lname;
            this.Country = Country;
            this.State = State;
            this.City = City;
            this.Suburb = suburb;
            this.Postcode = postcode;
            this.StreetName = streetName;
            this.StreetNumber = streetNumber;
            this.PropertyName = propertyName;
            this.Email = email;

        }

        public void addPaymentData(string cardNumber, string cardholdersName, string cardStartDate, string cardEndDate, string cardIssueNumber)
        {
            this.CardHoldersName = cardholdersName;
            this.CardNumber = cardNumber;
            this.CardStartDate = cardStartDate;
            this.CardEndDate = cardEndDate;
            this.CardIssueNumber = cardIssueNumber;
        }

        public string GetCardHoldersName(){
            return this.CardHoldersName;
        }

		public string GetCardStartDate()
		{
			return this.CardStartDate;
		}

		public string GetCardEndDate()
		{
			return this.CardEndDate;
		}

		public string GetCardIssueNumber()
		{
			return this.CardIssueNumber;
		}

		public string GetCardNumber()
		{
			return this.CardNumber;
		}

        public string GetAddress()
        {
            return this.StreetNumber + " " + this.StreetName + " " + this.Suburb + " " + this.City + " " + this.State + " " + this.Country;
        }
        public string GetName()
        {
            return this.Title + " " + this.Fname + " " + Mname + " " + Lname;
        }
        public void Insert(Customer customer)
        {
            this.ID = customer.ID;
            this.Title = customer.Title;
            this.Fname = customer.Fname;
            this.Mname = customer.Mname;
            this.Lname = customer.Lname;
            this.Country = customer.Country;
            this.State = customer.State;
            this.City = customer.City;
            this.Suburb = customer.Suburb;
            this.Postcode = customer.Postcode;
            this.StreetName = customer.StreetName;
            this.StreetNumber = customer.StreetNumber;
            this.PropertyName = customer.PropertyName;
        }


        public void test()
        {
            Console.Write("Hello");
        }
    }
}