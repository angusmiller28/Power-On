﻿using System;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace miller0061072133.Views
{
    public partial class Payment : System.Web.UI.Page
    {
        Customer customer;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["customer"] == null)
            {
                Session["customer"] = new Customer();
            }

            customer = (Customer)Session["customer"];


            if (!IsPostBack) //check if the webpage is loaded for the first time.
            {
                ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState
            }
        }
       
        protected void btnBack_Click(object sender, EventArgs e)
        {
            if (ViewState["PreviousPage"] != null)  //Check if the ViewState 
                                                    //contains Previous page URL
            {
                Response.Redirect(ViewState["PreviousPage"].ToString());//Redirect to 
                                                                        //Previous page by retrieving the PreviousPage Url from ViewState.
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            // get customer payment data for session
            //string title = lst_title.Text;

            bool valid = ValidateData(txt_card_number.Text, txt_cardholders_name.Text, txt_card_start_date.Text, txt_card_end_date.Text, txt_card_issue_number.Text);

            if (valid){
				// save customer data to session
				customer.addPaymentData(txt_card_number.Text, txt_cardholders_name.Text, txt_card_start_date.Text, txt_card_end_date.Text, txt_card_issue_number.Text); 
				Response.Redirect("Review.aspx");
            }

        }

        private bool ValidateData(string cardNumber, string cardholder, string cardStart, string cardEnd, string cardIssueNumber){
            bool allValid = true;
            lbl_error.Text = "";
            lbl_card_type.Text = "";
			lbl_error.Text = "";

            // credit card match
            // mastercard
			Regex id_exp = new Regex(@"^4[0-9]{12}(?:[0-9]{3})?$"); // for visa
			Match visa = id_exp.Match(cardNumber);
			id_exp = new Regex(@"^(?:5[1-5][0-9]\d{1}|222[1-9]|2[3-6][0-9]\d{1}|27[01][0-9]|2‌​720)([\ \-]?)\d{4}\1\d{4}\1\d{4}$"); // for visa mastercard
			Match mastercard = id_exp.Match(cardNumber);
			id_exp = new Regex(@"^(62[0-9]{14,17})$"); // for union pay
			Match unionPay = id_exp.Match(cardNumber);
			if (visa.Success){ // Visa Card
                lbl_card_type.Text = "Card Type: Visa";
			} else if(mastercard.Success){ // Visa Master Card
                lbl_card_type.Text = "Card Type: Visa Master Card";
            } else if (unionPay.Success){
                lbl_card_type.Text = "Card Type: Union Pay Card";
            } else {
				lbl_error.Text += "- Card Number is invalid -";
				allValid = false;
            }

			Regex name_exp = new Regex(@"^*[A-Za-z]$");
			Match match = name_exp.Match(cardholder);
			if (match.Success == false)
			{
				lbl_error.Text += "- Card holder is invalid -";
				allValid = false;
			}

			// validate cvv 
            Regex cvv_exp = new Regex(@"^[0-9]{3}$");
			match = cvv_exp.Match(cardIssueNumber);
			if (match.Success == false)
			{
                lbl_error.Text += "- Card Issue Number (CVV) is invalid -";
				allValid = false;
			}

			// validate dates 
			Regex date_exp = new Regex(@"^(0[1-9]|1[0-2])\/?([0-9]{4}|[0-9]{2})$");
			match = date_exp.Match(cardStart);
			if (match.Success == false)
			{
				lbl_error.Text += "- Card Issue Date is invalid -";
				allValid = false;
			}

			match = date_exp.Match(cardEnd);
			if (match.Success == false)
			{
				lbl_error.Text += "- Card Expiry is invalid -";
				allValid = false;
			}

            if (allValid){
              return true;  
            }
            return false;    
        }
   
    }
}