﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace miller0061072133.Views
{
    public partial class Review : System.Web.UI.Page
    {
        Customer customer;
        Cart myCart;
        protected void Page_Load(object sender, EventArgs e)
        {
            // fill data
            fillData();
            if (!IsPostBack) //check if the webpage is loaded for the first time.
            {
                ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState
            }
        }

        private void fillData(){
			if (Session["customer"] == null)
			{
				Session["customer"] = new Customer();
			}

			customer = (Customer)Session["customer"];

			
            if (Session["myCart"] == null)
			{
				Session["myCart"] = new Cart();
			}

			myCart = (Cart)Session["myCart"];

            // product details
            double grand_total = 0.00;
			foreach (CartItem item in Items)
			{
                Label lbl_id = new Label();
                Label lbl_p_name = new Label();
                Label lbl_price = new Label();
                Label lbl_quantity = new Label();
                Label lbl_image = new Label();

                // set ids
                lbl_id.ID = "lbl_id";
                lbl_p_name.ID = "lbl_p_name";
                lbl_price.ID = "lbl_price";
                lbl_quantity.ID = "lbl_quantity";
                lbl_image.ID = "lbl_image";

                // set data
                lbl_id.Text = item.GetID();
                lbl_p_name.Text = item.GetName();
                lbl_price.Text = item.GetPrice().ToString();
                lbl_quantity.Text = item.GetQuantity().ToString(); 
                lbl_image.Text = item.GetImage();

                PlaceHolder1.Controls.Add(lbl_id);
                PlaceHolder2.Controls.Add(lbl_p_name);
                PlaceHolder3.Controls.Add(lbl_price);
                PlaceHolder4.Controls.Add(lbl_quantity);
				PlaceHolder5.Controls.Add(lbl_image);

				grand_total += item.Quantity * item.Price;
			}
            lbl_grand_total.Text = grand_total.ToString();

            // customer details
            txt_name.Text = customer.GetName();
            txt_address.Text = customer.GetAddress();

            // payment details
            txt_cardholders_name.Text = customer.GetCardHoldersName();
            txt_card_number.Text = customer.GetCardNumber();
            txt_card_start_date.Text = customer.GetCardStartDate();
            txt_card_end_date.Text = customer.GetCardEndDate();
            txt_card_issue_number.Text = customer.GetCardIssueNumber();
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            if (ViewState["PreviousPage"] != null)  //Check if the ViewState 
                                                    //contains Previous page URL
            {
                Response.Redirect(ViewState["PreviousPage"].ToString());//Redirect to 
                                                                        //Previous page by retrieving the PreviousPage Url from ViewState.
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("ProccessedPayment.aspx");
        }
    }
}