﻿using System.Web;

namespace miller
{
    public class Global : HttpApplication
    {
        protected void Application_Start()
        {
        }
    }
}
